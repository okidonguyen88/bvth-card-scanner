import React from 'react';
import { PrintIcon, RetakeIcon } from './Icons';

// Define the Electron API on the window object for JavaScript.
window.electronAPI = window.electronAPI || {};

function FinalPreview({ croppedImageSrc, onStartOver }) {
  const handlePrint = () => {
    if (window.electronAPI && window.electronAPI.printImage) {
      window.electronAPI.printImage(croppedImageSrc).catch(err => {
        console.error("Electron print failed:", err);
        alert("There was an error trying to print the image.");
      });
    } else {
      console.warn("Electron API not found. Falling back to browser printing.");
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Print ID Card</title>
              <style>
                @page { size: auto; margin: 0; }
                body { margin: 0; padding: 0; }
                img { width: 100%; height: auto; display: block; }
              </style>
            </head>
            <body>
              <img src="${croppedImageSrc}" onload="window.print(); window.close();" alt="Cropped ID Card" />
            </body>
          </html>
        `);
        printWindow.document.close();
      }
    }
  };

  return (
    <div className="bg-slate-800 p-6 rounded-xl shadow-2xl border border-slate-700 text-center">
      <h2 className="text-3xl font-bold text-slate-100 mb-4">Cắt hình ảnh của bạn</h2>
      <p className="text-slate-300 mb-6">Hình ảnh đã sẵn sàng. Bạn có thể in nó hoặc bắt đầu lại.</p>
      <div className="mb-6 bg-slate-900/50 p-4 rounded-lg border border-slate-700 inline-block">
        <img src={croppedImageSrc} alt="Final Cropped ID" className="max-w-xs md:max-w-sm rounded-md shadow-lg" />
      </div>
      <div className="flex justify-center items-center gap-4 no-print">
        <button
          onClick={onStartOver}
          className="group inline-flex items-center justify-center gap-2 bg-slate-600 hover:bg-slate-700 text-white font-bold py-3 px-6 rounded-lg transition-colors duration-300"
        >
          <RetakeIcon className="w-5 h-5"/>
          <span>Bắt đầu lại</span>
        </button>
        <button
          onClick={handlePrint}
          className="group inline-flex items-center justify-center gap-3 bg-teal-600 hover:bg-teal-700 text-white font-bold text-lg py-3 px-8 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg"
        >
          <PrintIcon className="w-6 h-6"/>
          <span>In</span>
        </button>
      </div>
    </div>
  );
}

export default FinalPreview;